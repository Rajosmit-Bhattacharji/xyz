package com.careweave.app.risk

import com.careweave.app.data.*

object RiskEngine {
    /**
     * Prototype triage rules for CAREWEAVE demonstration.
     * These are NOT a diagnostic/medical-device decision system.
     * Thresholds should be clinically validated before deployment.
     */
    fun evaluate(v: VitalReading): RiskResult {
        var score = 0
        val reasons = mutableListOf<String>()

        if (v.temperature >= 38.0) { score += 3; reasons += "fever-range temperature" }
        else if (v.temperature >= 37.5) { score += 1; reasons += "elevated temperature" }

        if (v.heartRate >= 120 || v.heartRate <= 50) { score += 3; reasons += "marked heart-rate change" }
        else if (v.heartRate >= 100 || v.heartRate <= 55) { score += 1; reasons += "elevated/low heart rate" }

        if (v.respiration >= 24 || v.respiration <= 10) { score += 3; reasons += "abnormal respiration" }
        else if (v.respiration >= 20) { score += 1; reasons += "elevated respiration" }

        // Combination rules: stronger signal when abnormalities co-occur.
        if (v.temperature >= 38.0 && v.heartRate >= 100) score += 2
        if (v.heartRate >= 120 && v.respiration >= 24) score += 2
        if (v.temperature >= 38.0 && v.respiration >= 24) score += 2

        val level = when {
            score >= 7 -> RiskLevel.HIGH
            score >= 3 -> RiskLevel.MODERATE
            else -> RiskLevel.LOW
        }
        val message = when (level) {
            RiskLevel.LOW -> "No concerning combination detected."
            RiskLevel.MODERATE -> "A change is present. Recheck and consider contacting the care team."
            RiskLevel.HIGH -> "Multiple concerning changes detected. Seek urgent medical assessment."
        }
        return RiskResult(level, score, if (reasons.isEmpty()) message else "$message (${reasons.joinToString()}).")
    }
}
