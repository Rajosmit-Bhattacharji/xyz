package com.careweave.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CareweaveDao {
    @Insert suspend fun insertReading(reading: ReadingEntity)
    @Query("SELECT * FROM readings ORDER BY timestamp DESC LIMIT :limit")
    fun observeReadings(limit: Int = 500): Flow<List<ReadingEntity>>
    @Query("SELECT * FROM readings ORDER BY timestamp DESC LIMIT 1")
    suspend fun latestReading(): ReadingEntity?

    @Insert suspend fun insertAlert(alert: AlertEntity)
    @Query("SELECT * FROM alerts ORDER BY timestamp DESC LIMIT 100")
    fun observeAlerts(): Flow<List<AlertEntity>>
    @Query("UPDATE alerts SET acknowledged = 1 WHERE id = :id")
    suspend fun acknowledge(id: Long)
}
