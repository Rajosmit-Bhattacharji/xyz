package com.careweave.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

data class VitalReading(
    val timestamp: Long,
    val heartRate: Int,
    val temperature: Double,
    val respiration: Int
)

enum class RiskLevel { LOW, MODERATE, HIGH }

data class RiskResult(
    val level: RiskLevel,
    val score: Int,
    val message: String
)

@Entity(tableName = "readings")
data class ReadingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val heartRate: Int,
    val temperature: Double,
    val respiration: Int,
    val risk: String
)

@Entity(tableName = "alerts")
data class AlertEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val level: String,
    val title: String,
    val message: String,
    val acknowledged: Boolean = false
)

data class EmergencyContact(
    val name: String,
    val phone: String
)
