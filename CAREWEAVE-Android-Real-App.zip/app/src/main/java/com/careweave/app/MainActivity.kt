package com.careweave.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.careweave.app.data.*
import com.careweave.app.ble.DeviceState
import com.careweave.app.risk.RiskEngine
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNeededPermissions()
        setContent { CareweaveApp() }
    }

    private fun requestNeededPermissions() {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            p += Manifest.permission.BLUETOOTH_SCAN
            p += Manifest.permission.BLUETOOTH_CONNECT
        }
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        permissionLauncher.launch(p.toTypedArray())
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CareweaveApp(vm: AppViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("CAREWEAVE", fontWeight = FontWeight.Bold) }) },
        bottomBar = {
            NavigationBar {
                listOf("Home" to Icons.Default.Home, "Trends" to Icons.Default.ShowChart,
                    "Alerts" to Icons.Default.Notifications, "Settings" to Icons.Default.Settings)
                    .forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, null) }, label = { Text(label) })
                    }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            when(tab) {
                0 -> Dashboard(vm)
                1 -> Trends(vm)
                2 -> Alerts(vm)
                3 -> Settings(vm)
            }
        }
    }
}

@Composable
fun Dashboard(vm: AppViewModel) {
    val reading by vm.currentReading.collectAsState()
    val state by vm.connectionState.collectAsState()
    val demo by vm.demoMode.collectAsState()
    val risk = reading?.let(RiskEngine::evaluate)
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Maternal wellness", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(if (demo) "Demo Mode • simulated sensor stream" else "Live sensor monitoring")
            }
            ConnectionPill(state, demo)
        }
        Spacer(Modifier.height(14.dp))
        risk?.let { RiskCard(it) } ?: Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("No reading yet", fontWeight = FontWeight.Bold)
                Text("Connect the CAREWEAVE ESP32 or enable Demo Mode.")
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            VitalCard("Heart rate", reading?.heartRate?.toString() ?: "—", "bpm", Modifier.weight(1f))
            VitalCard("Temperature", reading?.temperature?.let { "%.1f".format(it) } ?: "—", "°C", Modifier.weight(1f))
            VitalCard("Respiration", reading?.respiration?.toString() ?: "—", "rpm", Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Device", fontWeight = FontWeight.Bold)
                Text(if (demo) "Simulation pipeline active" else state.name.replace("_", " ").lowercase().replaceFirstChar { it.uppercase() })
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.startBle() }, enabled = !demo) { Text("Connect ESP32") }
                    OutlinedButton(onClick = { vm.setDemoMode(!demo) }) { Text(if (demo) "Stop Demo" else "Demo Mode") }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Prototype safety note: this app is for monitoring/research demonstration and does not diagnose medical conditions.", fontSize = 12.sp)
    }
}

@Composable
fun ConnectionPill(state: DeviceState, demo: Boolean) {
    val text = if (demo) "DEMO" else when(state) {
        DeviceState.CONNECTED -> "CONNECTED"
        DeviceState.SCANNING, DeviceState.CONNECTING -> "CONNECTING"
        DeviceState.ERROR -> "ERROR"
        else -> "OFFLINE"
    }
    AssistChip(onClick = {}, label = { Text(text) },
        leadingIcon = { Icon(if (demo || state == DeviceState.CONNECTED) Icons.Default.BluetoothConnected else Icons.Default.BluetoothDisabled, null) })
}

@Composable
fun RiskCard(r: RiskResult) {
    val title = when(r.level) { RiskLevel.LOW -> "LOW RISK"; RiskLevel.MODERATE -> "MODERATE RISK"; RiskLevel.HIGH -> "HIGH RISK" }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text("Risk score ${r.score}")
            Spacer(Modifier.height(5.dp))
            Text(r.message)
        }
    }
}

@Composable
fun VitalCard(title: String, value: String, unit: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontSize = 12.sp)
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(unit, fontSize = 12.sp)
        }
    }
}

@Composable
fun Trends(vm: AppViewModel) {
    val readings by vm.history.collectAsState(initial = emptyList())
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Trends", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Locally stored readings • newest first")
        Spacer(Modifier.height(12.dp))
        TrendChart("Heart rate (bpm)", readings.reversed().takeLast(60).map { it.heartRate.toFloat() })
        TrendChart("Temperature (°C)", readings.reversed().takeLast(60).map { it.temperature.toFloat() })
        TrendChart("Respiration (rpm)", readings.reversed().takeLast(60).map { it.respiration.toFloat() })
    }
}

@Composable
fun TrendChart(title: String, values: List<Float>) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (values.size < 2) Text("Collect more readings to see the graph.", Modifier.padding(vertical = 20.dp))
            else Canvas(Modifier.fillMaxWidth().height(110.dp).padding(top = 8.dp)) {
                val min = values.minOrNull() ?: 0f
                val max = values.maxOrNull() ?: 1f
                val range = (max - min).coerceAtLeast(1f)
                val path = Path()
                values.forEachIndexed { i, v ->
                    val x = i * size.width / (values.size - 1)
                    val y = size.height - ((v - min) / range) * size.height
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, style = Stroke(width = 4f))
            }
        }
    }
}

@Composable
fun Alerts(vm: AppViewModel) {
    val alerts by vm.alerts.collectAsState(initial = emptyList())
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Alerts", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        if (alerts.isEmpty()) item { Text("No alerts. CAREWEAVE will show moderate/high-risk combinations here.") }
        items(alerts, key = { it.id }) { a ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp)) {
                    Text(a.title, fontWeight = FontWeight.Bold)
                    Text(a.message)
                    Text(SimpleDateFormat("dd MMM, HH:mm:ss", Locale.getDefault()).format(Date(a.timestamp)), fontSize = 12.sp)
                    if (!a.acknowledged) {
                        TextButton(onClick = { vm.acknowledge(a.id) }) { Text("Acknowledge") }
                    }
                }
            }
        }
    }
}

@Composable
fun Settings(vm: AppViewModel) {
    val contact by vm.contact.collectAsState()
    var name by remember(contact) { mutableStateOf(contact.name) }
    var phone by remember(contact) { mutableStateOf(contact.phone) }
    val context = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Care & emergency", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Emergency contact", fontWeight = FontWeight.Bold)
        OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(phone, { phone = it }, label = { Text("Phone number") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = { vm.saveContact(name, phone) }) { Text("Save contact") }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.emergencySms()?.let { context.startActivity(it) } }, enabled = phone.isNotBlank()) {
                Icon(Icons.Default.Message, null); Spacer(Modifier.width(5.dp)); Text("Emergency SMS")
            }
            OutlinedButton(onClick = { vm.callEmergency()?.let { context.startActivity(it) } }, enabled = phone.isNotBlank()) {
                Icon(Icons.Default.Call, null); Spacer(Modifier.width(5.dp)); Text("Call")
            }
        }
        Spacer(Modifier.height(18.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(15.dp)) {
                Text("Offline storage", fontWeight = FontWeight.Bold)
                Text("Readings and alerts are stored locally with Room, so the dashboard and graphs continue to work without internet.")
            }
        }
    }
}
