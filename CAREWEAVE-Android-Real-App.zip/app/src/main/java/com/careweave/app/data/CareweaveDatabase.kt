package com.careweave.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ReadingEntity::class, AlertEntity::class], version = 1, exportSchema = false)
abstract class CareweaveDatabase : RoomDatabase() {
    abstract fun dao(): CareweaveDao
    companion object {
        @Volatile private var INSTANCE: CareweaveDatabase? = null
        fun get(context: Context): CareweaveDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, CareweaveDatabase::class.java, "careweave.db"
                ).build().also { INSTANCE = it }
            }
    }
}
