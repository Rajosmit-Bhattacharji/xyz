package com.careweave.app

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.careweave.app.ble.*
import com.careweave.app.data.*
import com.careweave.app.risk.RiskEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.sin
import kotlin.random.Random

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val db = CareweaveDatabase.get(app)
    private val dao = db.dao()
    private val ble = BleManager(app)

    val connectionState = ble.state
    val deviceName = ble.deviceName
    val history = dao.observeReadings()
    val alerts = dao.observeAlerts()

    private val _currentReading = MutableStateFlow<VitalReading?>(null)
    val currentReading = _currentReading.asStateFlow()

    private val _demoMode = MutableStateFlow(false)
    val demoMode = _demoMode.asStateFlow()
    private var demoJob: Job? = null

    private val prefs = app.getSharedPreferences("careweave", Context.MODE_PRIVATE)
    private val _contact = MutableStateFlow(
        EmergencyContact(
            prefs.getString("contactName", "Emergency Contact") ?: "Emergency Contact",
            prefs.getString("contactPhone", "") ?: ""
        )
    )
    val contact = _contact.asStateFlow()

    init {
        // REAL BLE and DEMO both terminate in the exact same ingestReading() pipeline.
        viewModelScope.launch {
            ble.readings.filterNotNull().collect { ingestReading(it) }
        }
    }

    fun startBle() {
        setDemoMode(false)
        ble.startScan()
    }

    fun disconnect() = ble.disconnect()

    fun setDemoMode(enabled: Boolean) {
        _demoMode.value = enabled
        demoJob?.cancel()
        if (enabled) {
            ble.disconnect()
            demoJob = viewModelScope.launch {
                var tick = 0
                while (true) {
                    val reading = VitalReading(
                        System.currentTimeMillis(),
                        (78 + 7 * sin(tick / 5.0) + Random.nextInt(-2, 3)).toInt(),
                        36.6 + 0.25 * sin(tick / 8.0) + Random.nextDouble(-0.05, 0.05),
                        (15 + 2 * sin(tick / 6.0) + Random.nextInt(-1, 2)).toInt()
                    )
                    ingestReading(reading)
                    tick++
                    delay(2000)
                }
            }
        }
    }

    private fun ingestReading(v: VitalReading) {
        _currentReading.value = v
        viewModelScope.launch {
            val risk = RiskEngine.evaluate(v)
            dao.insertReading(
                ReadingEntity(
                    timestamp = v.timestamp,
                    heartRate = v.heartRate,
                    temperature = v.temperature,
                    respiration = v.respiration,
                    risk = risk.level.name
                )
            )
            if (risk.level != RiskLevel.LOW) {
                dao.insertAlert(
                    AlertEntity(
                        timestamp = v.timestamp,
                        level = risk.level.name,
                        title = "${risk.level.name} risk detected",
                        message = risk.message
                    )
                )
            }
        }
    }

    fun saveContact(name: String, phone: String) {
        prefs.edit().putString("contactName", name).putString("contactPhone", phone).apply()
        _contact.value = EmergencyContact(name, phone)
    }

    fun emergencySms(): Intent? {
        val p = contact.value.phone
        if (p.isBlank()) return null
        return Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:$p")
            putExtra("sms_body", "CAREWEAVE emergency alert: please check on the mother immediately.")
        }
    }

    fun callEmergency(): Intent? {
        val p = contact.value.phone
        if (p.isBlank()) return null
        return Intent(Intent.ACTION_DIAL).apply { data = Uri.parse("tel:$p") }
    }

    fun acknowledge(id: Long) = viewModelScope.launch { dao.acknowledge(id) }

    override fun onCleared() {
        demoJob?.cancel()
        ble.disconnect()
        super.onCleared()
    }
}
