package com.careweave.app.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import com.careweave.app.data.VitalReading
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

enum class DeviceState { DISCONNECTED, SCANNING, CONNECTING, CONNECTED, ERROR }

@SuppressLint("MissingPermission")
class BleManager(private val context: Context) {
    private val adapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private var gatt: BluetoothGatt? = null
    private var scanner: BluetoothLeScanner? = null
    private var target: BluetoothDevice? = null

    private val _state = MutableStateFlow(DeviceState.DISCONNECTED)
    val state: StateFlow<DeviceState> = _state.asStateFlow()
    private val _deviceName = MutableStateFlow<String?>(null)
    val deviceName: StateFlow<String?> = _deviceName.asStateFlow()
    private val _readings = MutableStateFlow<VitalReading?>(null)
    val readings: StateFlow<VitalReading?> = _readings.asStateFlow()

    fun startScan() {
        if (adapter?.isEnabled != true) { _state.value = DeviceState.ERROR; return }
        scanner = adapter.bluetoothLeScanner
        _state.value = DeviceState.SCANNING
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(BleProtocol.SERVICE_UUID)).build()
        scanner?.startScan(listOf(filter), ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCallback)
    }

    fun stopScan() {
        scanner?.stopScan(scanCallback)
        if (_state.value == DeviceState.SCANNING) _state.value = DeviceState.DISCONNECTED
    }

    fun disconnect() {
        stopScan()
        gatt?.close()
        gatt = null
        target = null
        _deviceName.value = null
        _state.value = DeviceState.DISCONNECTED
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            stopScan()
            target = result.device
            _deviceName.value = result.device.name ?: "CAREWEAVE ESP32"
            _state.value = DeviceState.CONNECTING
            gatt = result.device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        }
        override fun onScanFailed(errorCode: Int) { _state.value = DeviceState.ERROR }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                _state.value = DeviceState.CONNECTED
                g.discoverServices()
            } else {
                _state.value = DeviceState.DISCONNECTED
                g.close()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val service = g.getService(BleProtocol.SERVICE_UUID) ?: return
            val characteristic = service.getCharacteristic(BleProtocol.DATA_UUID) ?: return
            g.setCharacteristicNotification(characteristic, true)
            characteristic.getDescriptor(BleProtocol.CCCD_UUID)?.let {
                it.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                g.writeDescriptor(it)
            }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (characteristic.uuid == BleProtocol.DATA_UUID) {
                BleProtocol.parse(characteristic.value)?.let { _readings.value = it }
            }
        }
    }
}
