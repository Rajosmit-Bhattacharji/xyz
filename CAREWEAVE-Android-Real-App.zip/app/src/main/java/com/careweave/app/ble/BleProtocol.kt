package com.careweave.app.ble

import com.careweave.app.data.VitalReading
import org.json.JSONObject

/**
 * CAREWEAVE BLE protocol v1
 * Service: 6e400001-b5a3-f393-e0a9-e50e24dcca9e
 * Data characteristic: 6e400003-b5a3-f393-e0a9-e50e24dcca9e
 *
 * UTF-8 JSON notification:
 * {"hr":82,"temp":36.8,"rr":16,"ts":1720000000}
 *
 * ts is optional; Android uses receive time when absent.
 */
object BleProtocol {
    val SERVICE_UUID = java.util.UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
    val DATA_UUID = java.util.UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e")
    val CCCD_UUID = java.util.UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    fun parse(payload: ByteArray): VitalReading? = runCatching {
        val json = JSONObject(payload.toString(Charsets.UTF_8).trim())
        val hr = json.getInt("hr")
        val temp = json.getDouble("temp")
        val rr = json.getInt("rr")
        require(hr in 30..220 && temp in 25.0..45.0 && rr in 5..60)
        VitalReading(
            timestamp = if (json.has("ts")) json.getLong("ts") * 1000L else System.currentTimeMillis(),
            heartRate = hr,
            temperature = temp,
            respiration = rr
        )
    }.getOrNull()

    fun encode(reading: VitalReading): ByteArray =
        JSONObject().apply {
            put("hr", reading.heartRate)
            put("temp", reading.temperature)
            put("rr", reading.respiration)
            put("ts", reading.timestamp / 1000L)
        }.toString().toByteArray(Charsets.UTF_8)
}
