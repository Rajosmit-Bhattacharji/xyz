# CAREWEAVE — Real Android + ESP32 BLE Prototype

A functional Android prototype for the CAREWEAVE smart-textile concept in the supplied presentation. The presentation describes textile sensors feeding a detachable Bluetooth/Wi-Fi module and a mobile app, with long-term logging and a three-tier alert route. See pages 5 and 8 of the supplied deck.

## What is implemented

- Native Android app (Kotlin + Jetpack Compose)
- Real BLE scanning, connection and GATT notifications
- Live heart rate, skin temperature and respiration dashboard
- Local offline persistence with Room
- Trend graphs
- LOW / MODERATE / HIGH prototype risk engine using combinations
- Persistent alert history + acknowledge
- Emergency contact storage
- Emergency SMS composer and call action
- Demo Mode using the same `VitalReading -> RiskEngine -> Room -> UI` pipeline as BLE
- Included ESP32 Arduino/NimBLE example

## BLE protocol v1

Advertise service UUID:

`6e400001-b5a3-f393-e0a9-e50e24dcca9e`

Notify on characteristic:

`6e400003-b5a3-f393-e0a9-e50e24dcca9e`

UTF-8 JSON payload:

`{"hr":82,"temp":36.8,"rr":16,"ts":1720000000}`

- `hr`: beats/min
- `temp`: °C
- `rr`: breaths/min
- `ts`: optional Unix timestamp in seconds

The Android parser validates sensible ranges before accepting a packet.

## Build

Open this folder in Android Studio (Ladybug/compatible current Android Studio) and let Gradle sync. Use a physical Android phone for BLE testing.

For Android 12+, grant Bluetooth Scan and Connect. For Android 13+, grant notification permission if you want notification integration added later.

## ESP32

Install the NimBLE-Arduino library, open `esp32/CareweaveEsp32.ino`, select an ESP32 board and flash it. The example generates sensor-like values; replace `readHeartRate()`, `readTemperature()` and `readRespiration()` with your actual sensor drivers.

## Important prototype boundary

The supplied CAREWEAVE presentation proposes early warning and mentions MEOWS, but the app's thresholds are explicitly prototype rules and are not a clinically validated MEOWS implementation. The presentation itself says clinical validation against medical-grade telemetry is part of the roadmap (page 9). Do not use the prototype risk label as a diagnosis or as a substitute for professional care.
