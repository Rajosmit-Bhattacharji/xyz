#include <NimBLEDevice.h>
#include <ArduinoJson.h>

static NimBLECharacteristic* dataCharacteristic;

#define SERVICE_UUID "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define DATA_UUID    "6e400003-b5a3-f393-e0a9-e50e24dcca9e"

void setup() {
  Serial.begin(115200);
  NimBLEDevice::init("CAREWEAVE-ESP32");

  NimBLEServer* server = NimBLEDevice::createServer();
  NimBLEService* service = server->createService(SERVICE_UUID);

  dataCharacteristic = service->createCharacteristic(
      DATA_UUID, NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::NOTIFY);

  service->start();

  NimBLEAdvertising* advertising = NimBLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->start();

  Serial.println("CAREWEAVE BLE ready");
}

int readHeartRate() {
  // Replace with your PPG/ECG driver.
  return 78 + random(-3, 4);
}

float readTemperature() {
  // Replace with your skin-temperature sensor driver.
  return 36.6 + random(-10, 11) / 100.0;
}

int readRespiration() {
  // Replace with textile stretch/strain sensor processing.
  return 15 + random(-2, 3);
}

void loop() {
  StaticJsonDocument<128> doc;
  doc["hr"] = readHeartRate();
  doc["temp"] = readTemperature();
  doc["rr"] = readRespiration();
  doc["ts"] = (uint32_t)(millis() / 1000);

  char payload[128];
  serializeJson(doc, payload);
  dataCharacteristic->setValue((uint8_t*)payload, strlen(payload));
  dataCharacteristic->notify();

  delay(2000);
}
